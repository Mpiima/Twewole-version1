<?php if(1==1){ ?>
<script>
function status_checker(names, act){
var confirmer=confirm("Enjoy your 30-day trial as you showcase your products and services.  We’ll remind you when you have a few days left in your trial. Press Ok to continue.");
if(confirmer==false){return false;} }
</script>
<?php } ?>